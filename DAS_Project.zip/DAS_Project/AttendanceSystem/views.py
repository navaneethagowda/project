from django.shortcuts import render

def Login(request):
    return render(request,'AttendanceSystem/Login.html')

def registration(request):
    return render(request,'AttendanceSystem/registration.html')
