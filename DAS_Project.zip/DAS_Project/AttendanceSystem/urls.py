from django.urls import path
from . import views

urlpatterns = [
    path('', views.Login, name='System-Login'),
    path('registration/', views.registration, name='System-registration'),
]
