from django.apps import AppConfig


class AttendancesystemConfig(AppConfig):
    name = 'AttendanceSystem'
